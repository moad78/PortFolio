<?php
@include("connexion.php");


$a = $_POST["num_eleve"];
$b = $_POST["nom_eleve"];
$c = $_POST["Adresse"];
$d = $_POST["Num_telephone"];

$reql = "INSERT INTO eleves VALUES ('$a', '$b', '$c', '$d')";
$rl = mysqli_query($conn, $reql);

// Message de retour
echo "<center><p>Eleve ajouté OK</p></center>";
echo '<center><a href="menu.html">Retour</a></center>';

mysqli_close($conn);
?>
