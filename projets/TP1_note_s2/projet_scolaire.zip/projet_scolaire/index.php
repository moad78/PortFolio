<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="log2.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
</head>
<body>
    <form action="login.php" method="post">
        <center><h1>Se connecter</h1></center>
        <center><div>
        Nom de Login : <input type="text" name="login" class="style1"><br>
        Mot de passe : <input type="password" name="mdp" class="style2"><br>
    
        <input type="submit" value="Identifiez vous" class="style"><br>
        <input type="reset" value="annuler" class="style"><br>
        <a href="enregistrer.html">S'enregistrer</a>
        </div></center>
        </form>
        
    
</body>
</html>
