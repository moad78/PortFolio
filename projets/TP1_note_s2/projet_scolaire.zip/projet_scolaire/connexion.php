<?php
 $conn=mysqli_connect("localhost","root","mysql", "scolaire_test");

 ?>
