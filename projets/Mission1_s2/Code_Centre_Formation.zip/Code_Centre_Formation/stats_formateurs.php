<?php

$host = "sql200.infinityfree.com";
$user = "if0_41006633";
$password = "2LlSuhAE8L";
$database = "if0_41006633_centre_formation";

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Erreur de connexion : " . mysqli_connect_error());
}

$sql_total = "SELECT COUNT(*) AS total_formateurs FROM formateurs";
$result_total = mysqli_query($conn, $sql_total);

$sql_formations = "
SELECT f.nom, f.prenom, COUNT(fo.id_formation) AS nb_formations
FROM formateurs f
LEFT JOIN formations fo ON f.id_formateur = fo.id_formateur
GROUP BY f.id_formateur
";
$result_formations = mysqli_query($conn, $sql_formations);

$sql_modules = "
SELECT f.nom, f.prenom, COUNT(m.id_module) AS nb_modules
FROM formateurs f
LEFT JOIN formations fo ON f.id_formateur = fo.id_formateur
LEFT JOIN modules m ON fo.id_formation = m.id_formation
GROUP BY f.id_formateur
";
$result_modules = mysqli_query($conn, $sql_modules);

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Statistiques formateurs</title>
    <link rel="stylesheet" href="page.css">
</head>
<body>

<h2>Statistiques formateurs</h2>

<h3>Nombre total de formateurs</h3>
<table>
    <tr><th>Total formateurs</th></tr>
    <?php
    if ($result_total && mysqli_num_rows($result_total) > 0) {
        $row = mysqli_fetch_assoc($result_total);
        echo "<tr><td>".$row['total_formateurs']."</td></tr>";
    } else {
        echo "<tr><td>Aucun résultat.</td></tr>";
    }
    ?>
</table>

<h3>Nombre de formations par formateur</h3>
<table>
    <tr>
        <th>Nom</th>
        <th>Prénom</th>
        <th>Nb formations</th>
    </tr>
    <?php
    if ($result_formations && mysqli_num_rows($result_formations) > 0) {
        while ($row = mysqli_fetch_assoc($result_formations)) {
            echo "<tr>";
            echo "<td>".$row['nom']."</td>";
            echo "<td>".$row['prenom']."</td>";
            echo "<td>".$row['nb_formations']."</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='3'>Aucun résultat.</td></tr>";
    }
    ?>
</table>

<h3>Statistique bonus : nombre de modules (au total) par formateur</h3>
<table>
    <tr>
        <th>Nom</th>
        <th>Prénom</th>
        <th>Nb modules</th>
    </tr>
    <?php
    if ($result_modules && mysqli_num_rows($result_modules) > 0) {
        while ($row = mysqli_fetch_assoc($result_modules)) {
            echo "<tr>";
            echo "<td>".$row['nom']."</td>";
            echo "<td>".$row['prenom']."</td>";
            echo "<td>".$row['nb_modules']."</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='3'>Aucun résultat.</td></tr>";
    }

    mysqli_close($conn);
    ?>
</table>

<a href="index.php">Accueil</a>
</body>
</html>
