<?php

$host = "sql200.infinityfree.com";
$user = "if0_41006633";
$password = "2LlSuhAE8L";
$database = "if0_41006633_centre_formation";

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Erreur de connexion : " . mysqli_connect_error());
}

$sql_total = "SELECT COUNT(*) AS total_etudiants FROM etudiants";
$result_total = mysqli_query($conn, $sql_total);

$sql_par_formation = "
SELECT f.intitule, COUNT(i.id_etudiant) AS nb_etudiants
FROM inscriptions i
JOIN formations f ON i.id_formation = f.id_formation
GROUP BY f.intitule
";
$result_par_formation = mysqli_query($conn, $sql_par_formation);

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Statistiques étudiants</title>
    <link rel="stylesheet" href="page.css">
</head>
<body>

<h2>Statistiques étudiants</h2>

<h3>Nombre total d’étudiants</h3>
<table>
    <tr>
        <th>Total étudiants</th>
    </tr>
    <?php
    if ($result_total && mysqli_num_rows($result_total) > 0) {
        $row = mysqli_fetch_assoc($result_total);
        echo "<tr><td>".$row['total_etudiants']."</td></tr>";
    } else {
        echo "<tr><td>Aucun résultat.</td></tr>";
    }
    ?>
</table>

<h3>Nombre d’étudiants par formation</h3>
<table>
    <tr>
        <th>Formation</th>
        <th>Nombre d'étudiants</th>
    </tr>

    <?php
    if ($result_par_formation && mysqli_num_rows($result_par_formation) > 0) {
        while ($row = mysqli_fetch_assoc($result_par_formation)) {
            echo "<tr>";
            echo "<td>".$row['intitule']."</td>";
            echo "<td>".$row['nb_etudiants']."</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='2'>Aucune inscription trouvée.</td></tr>";
    }

    mysqli_close($conn);
    ?>
</table>

<a href="index.php">Accueil</a>
</body>
</html>
