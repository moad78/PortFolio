// Micro animations + apparitions des cartes
document.addEventListener("DOMContentLoaded", () => {
  const cards = document.querySelectorAll(".card");

  // apparition progressive
  cards.forEach((card, i) => {
    card.style.opacity = "0";
    card.style.transform = "translateY(10px)";
    card.style.transition = "opacity .35s ease, transform .35s ease";
    setTimeout(() => {
      card.style.opacity = "1";
      card.style.transform = "translateY(0)";
    }, 60 + i * 40);
  });

  // effet "tap" au clic
  cards.forEach(card => {
    card.addEventListener("mousedown", () => {
      card.style.transform = "translateY(-1px) scale(0.99)";
    });
    card.addEventListener("mouseup", () => {
      card.style.transform = "";
    });
    card.addEventListener("mouseleave", () => {
      card.style.transform = "";
    });
  });
});