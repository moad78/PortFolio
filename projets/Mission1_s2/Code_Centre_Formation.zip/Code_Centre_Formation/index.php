<?php
// Page d'accueil avec menu simple
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Accueil - Gestion d'une bibliothèque</title>

  
  <link rel="stylesheet" href="style.css">
</head>
<body>

<header class="topbar">
  <div class="topbar__inner">
    <div class="brand">
      <span class="brand__logo">📚</span>
      <span class="brand__name">Bibliothèque de Moad</span>
    </div>

    <nav class="menu">
      <a class="menu__link is-active" href="index.php">🏠 Accueil</a>
    </nav>
  </div>
</header>

<main class="container">
  <section class="hero">
    <h1>Bienvenue dans la Gestion de la bibliothèque 📖✨</h1>
    <p>Choisis une section pour afficher les informations de la base de données.</p>

    <div class="quick-actions">
      <span class="pill">⚡ Rapide</span>
      <span class="pill">🧠 Clair</span>
      <span class="pill">📊 Données</span>
      <span class="pill">🔎 Requêtes</span>
    </div>
  </section>

  <section class="grid" id="cards">
    <a class="card" href="stats_etudiants.php" data-icon="📚">
      <div class="card__icon">📚</div>
      <div class="card__content">
        <div class="card__title">Liste des Livres</div>
        <div class="card__desc">Voir tous les ouvrages enregistrés.</div>
      </div>
      <div class="card__arrow">➜</div>
    </a>

    <a class="card" href="stats_formations.php" data-icon="👥">
      <div class="card__icon">👥</div>
      <div class="card__content">
        <div class="card__title">Liste des Adhérents</div>
        <div class="card__desc">Accéder aux membres de la bibliothèque.</div>
      </div>
      <div class="card__arrow">➜</div>
    </a>

    <a class="card" href="stats_notes.php" data-icon="📦">
      <div class="card__icon">📦</div>
      <div class="card__content">
        <div class="card__title">Liste des Emprunts</div>
        <div class="card__desc">Consulter les emprunts en cours et passés.</div>
      </div>
      <div class="card__arrow">➜</div>
    </a>

    <a class="card" href="stats_formateurs.php" data-icon="✅">
      <div class="card__icon">✅</div>
      <div class="card__content">
        <div class="card__title">Livres en bon état</div>
        <div class="card__desc">Filtrer les livres en bon état.</div>
      </div>
      <div class="card__arrow">➜</div>
    </a>

    <a class="card" href="liste_etudiants_formations.php" data-icon="🆓">
      <div class="card__icon">🆓</div>
      <div class="card__content">
        <div class="card__title">Livres non empruntés</div>
        <div class="card__desc">Trouver les livres disponibles.</div>
      </div>
      <div class="card__arrow">➜</div>
    </a>
  </section>
</main>

<footer class="footer">
  <div class="footer__inner">
    <span>📚 Gestion de bibliothèque</span>
  </div>
</footer>


<script src="app.js"></script>
</body>
</html>
