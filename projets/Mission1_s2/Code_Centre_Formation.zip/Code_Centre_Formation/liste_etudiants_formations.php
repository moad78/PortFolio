<?php

$host = "sql200.infinityfree.com";
$user = "if0_41006633";
$password = "2LlSuhAE8L";
$database = "if0_41006633_centre_formation";

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Erreur de connexion : " . mysqli_connect_error());
}

$sql = "
SELECT e.nom, e.prenom, f.intitule, i.date_inscription
FROM inscriptions i
JOIN etudiants e ON i.id_etudiant = e.id_etudiant
JOIN formations f ON i.id_formation = f.id_formation
ORDER BY f.intitule, e.nom
";
$result = mysqli_query($conn, $sql);

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste étudiants et formations</title>
    <link rel="stylesheet" href="page.css">
</head>
<body>

<h2>Liste des étudiants et des formations</h2>

<table>
    <tr>
        <th>Nom</th>
        <th>Prénom</th>
        <th>Formation</th>
        <th>Date d'inscription</th>
    </tr>

    <?php
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>".$row['nom']."</td>";
            echo "<td>".$row['prenom']."</td>";
            echo "<td>".$row['intitule']."</td>";
            echo "<td>".$row['date_inscription']."</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='4'>Aucune inscription trouvée.</td></tr>";
    }

    mysqli_close($conn);
    ?>
</table>

<a href="index.php">Accueil</a>
</body>
</html>
