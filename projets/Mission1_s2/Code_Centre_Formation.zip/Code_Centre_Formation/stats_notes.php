<?php

$host = "sql200.infinityfree.com";
$user = "if0_41006633";
$password = "2LlSuhAE8L";
$database = "if0_41006633_centre_formation";

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Erreur de connexion : " . mysqli_connect_error());
}

$sql_moyenne = "SELECT AVG(note) AS moyenne_generale FROM notes";
$result_moyenne = mysqli_query($conn, $sql_moyenne);

$sql_minmax = "SELECT MAX(note) AS note_max, MIN(note) AS note_min FROM notes";
$result_minmax = mysqli_query($conn, $sql_minmax);

$sql_par_etudiant = "
SELECT e.nom, e.prenom, AVG(n.note) AS moyenne
FROM notes n
JOIN etudiants e ON n.id_etudiant = e.id_etudiant
GROUP BY e.id_etudiant
";
$result_par_etudiant = mysqli_query($conn, $sql_par_etudiant);

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Statistiques notes</title>
    <link rel="stylesheet" href="page.css">
</head>
<body>

<h2>Statistiques notes</h2>

<h3>Moyenne générale des notes</h3>
<table>
    <tr><th>Moyenne générale</th></tr>
    <?php
    if ($result_moyenne && mysqli_num_rows($result_moyenne) > 0) {
        $row = mysqli_fetch_assoc($result_moyenne);
        echo "<tr><td>".number_format($row['moyenne_generale'], 2)."</td></tr>";
    } else {
        echo "<tr><td>Aucun résultat.</td></tr>";
    }
    ?>
</table>

<h3>Note maximale et minimale</h3>
<table>
    <tr>
        <th>Note max</th>
        <th>Note min</th>
    </tr>
    <?php
    if ($result_minmax && mysqli_num_rows($result_minmax) > 0) {
        $row = mysqli_fetch_assoc($result_minmax);
        echo "<tr>";
        echo "<td>".$row['note_max']."</td>";
        echo "<td>".$row['note_min']."</td>";
        echo "</tr>";
    } else {
        echo "<tr><td colspan='2'>Aucun résultat.</td></tr>";
    }
    ?>
</table>

<h3>Moyenne par étudiant</h3>
<table>
    <tr>
        <th>Nom</th>
        <th>Prénom</th>
        <th>Moyenne</th>
    </tr>
    <?php
    if ($result_par_etudiant && mysqli_num_rows($result_par_etudiant) > 0) {
        while ($row = mysqli_fetch_assoc($result_par_etudiant)) {
            echo "<tr>";
            echo "<td>".$row['nom']."</td>";
            echo "<td>".$row['prenom']."</td>";
            echo "<td>".number_format($row['moyenne'], 2)."</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='3'>Aucune note trouvée.</td></tr>";
    }

    mysqli_close($conn);
    ?>
</table>

<a href="index.php">Accueil</a>
</body>
</html>
