<?php

$host = "sql200.infinityfree.com";
$user = "if0_41006633";
$password = "2LlSuhAE8L";
$database = "if0_41006633_centre_formation";

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Erreur de connexion : " . mysqli_connect_error());
}

$sql_total = "SELECT COUNT(*) AS total_formations FROM formations";
$result_total = mysqli_query($conn, $sql_total);

$sql_modules = "
SELECT f.intitule, COUNT(m.id_module) AS nb_modules
FROM modules m
JOIN formations f ON m.id_formation = f.id_formation
GROUP BY f.intitule
";
$result_modules = mysqli_query($conn, $sql_modules);

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Statistiques formations</title>
    <link rel="stylesheet" href="page.css">
</head>
<body>

<h2>Statistiques formations</h2>

<h3>Nombre total de formations</h3>
<table>
    <tr><th>Total formations</th></tr>
    <?php
    if ($result_total && mysqli_num_rows($result_total) > 0) {
        $row = mysqli_fetch_assoc($result_total);
        echo "<tr><td>".$row['total_formations']."</td></tr>";
    } else {
        echo "<tr><td>Aucun résultat.</td></tr>";
    }
    ?>
</table>

<h3>Nombre de modules par formation</h3>
<table>
    <tr>
        <th>Formation</th>
        <th>Nombre de modules</th>
    </tr>

    <?php
    if ($result_modules && mysqli_num_rows($result_modules) > 0) {
        while ($row = mysqli_fetch_assoc($result_modules)) {
            echo "<tr>";
            echo "<td>".$row['intitule']."</td>";
            echo "<td>".$row['nb_modules']."</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='2'>Aucun module trouvé.</td></tr>";
    }

    mysqli_close($conn);
    ?>
</table>

<a href="index.php">Accueil</a>
</body>
</html>
